package s201ApFRQ03;
/**
 * 
 * @author compsci
 *
 */

	/**
	 * Point +1
	 */
	public class CodeWordChecker implements StringChecker {
		
		/**
		 * @param minLength
		 * @param maxLength
		 * @param notAllowed
		 * Point +1 - declare header CodeWordChecker for class
		 */
		private int minLength;
		private int maxLength;
		private String notAllowed;
		
		/**
		 * 
		 * @param minLen smallest length of string required
		 * @param maxLen biggest length string can be
		 * @param symbol is the non  wanted string character thingy
		 * Point +3 ; declare CodeWordChecker with the 3 parameters +1, 
		 * use all params to initialize instance variables in 3- parameter constructor + 1,
		 * uses parameter and default values to initialize instance variables in 1- parameter constructor
		 */
		
		public CodeWordChecker(int minLen, int maxLen, String symbol)
		{
			minLength = minLen;
			maxLength = maxLen;
			notAllowed = symbol;
		}
		/**
		 * 
		 * @param symbol is the non wanted string character thingy
		 *
		 */
		public CodeWordChecker(String symbol) {
			minLength = 6;
			maxLength = 20;
			notAllowed = symbol;
		}
		/**
		 * @param str User string to be checked
		 * @return returns if criteria is met
		 * @category Point +4 ; Declare header +1, Check length min and max +1, check for unwanted string +1, returns true or false +1
		 */
		public boolean isValid(String str) { 
			return str.length() >= minLength && str.length()	 <= maxLength && str.indexOf(notAllowed) == -1;
		}

		

		

		
		
		
	}

