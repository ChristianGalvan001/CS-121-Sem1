package s201ApFRQ03;

public interface StringChecker{
	/**
	 * 
	 * @param str T
	 * @return
	 */
	public boolean isValid(String str);
	

		
	
	
	

}
