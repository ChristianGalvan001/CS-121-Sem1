import java.util.ArrayList;
/**
 * 
 * @author compsci
 *
 */
public class CoinCollectionTools {
	
	private Coin[][] coinBox;
	
	/**
	 * +2 points; uses array with nested loop; new coin objects for each cell
	 * @param country
	 * @param rows
	 * @param columns
	 */
	public CoinCollectionTools(String country, int rows, int columns) {
		coinBox = new Coin[rows][columns];
		for (int col = 0; col < columns; col++)
			for (int row = 0; row < rows; row++)
				coinBox[row][col] = new Coin(country,0,0);
	}
	
	
	 /**
	  * +4 points access every element; no bounds errors; accesses elements;returns correctly filled coinBox
	  * @param myCoins
	  * @return
	  */
	public Coin[][] fillCoinBox(ArrayList<Coin> myCoins)
	{
		int count = 0;
		int row = 0;
		int column = 0;
		
		
		while (count < myCoins.size())
		{
			coinBox[row][column] = myCoins.get(count);
			if (row < coinBox.length - 1 )
			{
				row++;
			}else {
				row = 0;
				column++;
			}
			count++;
		}
		return coinBox;
	}
	
	/**
	 * +3 points loops through columns in order; locates all types; instantiates and returns ArrayList<Coin>
	 * @return
	 */
	public ArrayList<Coin> fillCoinTypeList()
	{
		ArrayList<Coin> myCoins = new ArrayList<Coin>();
		for(int type = 1; type <= 6; type++)
			for(int col = 0; col < coinBox[0].length; col++)
				for(int row = 0; row < coinBox.length; row++)
					if(coinBox[row][col].getCoinType() == type) {
						myCoins.add(coinBox[row][col]);
						}
		return myCoins;
	}
	
	
	
	
//main------------------------------------------------------------------------
	public static void main(String[] args) {
		CoinCollectionTools tools = new CoinCollectionTools("USA", 3, 4);
		int [] years = {1,2,4,1,2,3,3,4,4,2,4};
		int [] types = {1,2,4,1,2,3,3,4,4,2,4};
		String[] typeNames = {"", "penny", "nickel", "dime", "quarter"};
		Coin[][] coinBox = new Coin[3][4];
		ArrayList<Coin> coins = new ArrayList<Coin>();
		
		
		for (int i = 0; i < years.length;i++) {
			coins.add(new Coin("USA", years[i], types[i]));
		}
		System.out.println("fillCoinBox test\n");
		coinBox = tools.fillCoinBox(coins);
		
		
		for(int row = 0; row < coinBox.length;row++) {
			
			for(int col = 0;col < coinBox[row].length;col++)
				System.out.println(typeNames[coinBox[row][col].getCoinType()] + " "
						+ coinBox[row][col].getYear());
			System.out.println();
			
		}
		
		
		System.out.println("\nfillCoinTypeList test\n");
		System.out.println("\n Test:");
		coins = tools.fillCoinTypeList();
		for (int i = 0; i < coins.size(); i++) {
			System.out.println(typeNames[coins.get(i).getCoinType()] + " " + coins.get(i).getYear()+ ", ");
			if (i == (coins.size() / 2 )) {
				System.out.println();
			}
			
		}
		
		
	}//end of main

}//end of class
