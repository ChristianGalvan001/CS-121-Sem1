package findtreasure;


public class StartHere {
	public static void main(String[] args) { 
		FindTreasure myTreasure = new FindTreasure();
		myTreasure.setVisible(true);
		
	}
	
	

}
