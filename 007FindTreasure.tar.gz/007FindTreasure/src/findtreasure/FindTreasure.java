package findtreasure;



import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import findtreasure.FindTreasure;



public class FindTreasure extends JFrame 
{
	  int x = 5;
	  int y = 5;
	  JLabel[][] choiceLabel = new JLabel[x][y];
	  ImageIcon good = new ImageIcon("Good1.png");
	  JButton newButton = new JButton();
	  int goodLocation;
	  Random myRandom = new Random();
	

	  public static void main(String args[])
	  {
	    // create frame
	    new FindTreasure().setVisible(true);
	  }

	  public FindTreasure()
	  {
	    // frame constructor
	    setTitle("Find the drawing - november 2018 - Christian Galvan");
	    setResizable(true);
	    addWindowListener(new WindowAdapter()
	    {
	      public void windowClosing(WindowEvent evt)
	      {
	        exitForm(evt);
	      }
	    });
	    getContentPane().setLayout(new GridBagLayout());
	    GridBagConstraints gridConstraints;
	    
	    
	    ImageIcon good = new ImageIcon("Good1.png");
		JButton newButton = new JButton();
		int goodLocation;
		Random myRandom = new Random();
				
	    for (int i = 0; i < 5; i++)
	    {
	      gridConstraints = new GridBagConstraints();
	      //want to make a for loop for y coordinate
	      choiceLabel[i][i].setPreferredSize(new Dimension(good.getIconWidth(), 
	              good.getIconHeight()));
	      choiceLabel[i][i].setOpaque(true);
	      choiceLabel[i][i].setBackground(Color.RED);
	      gridConstraints.gridx = i;
	      gridConstraints.gridy = 0;
	      gridConstraints.insets = new Insets(10, 10, 10, 10);
	      getContentPane().add(choiceLabel[i][i], gridConstraints);
	      choiceLabel[i][i].addMouseListener(new MouseAdapter()
	      {
	        public void mouseClicked(MouseEvent e)
	        {
	          labelMouseClicked(e);
	        }
	      });
	    }

	    newButton.setText("Play Again");
	    gridConstraints = new GridBagConstraints();
	    gridConstraints.gridx = 1;
	    gridConstraints.gridy = 1;
	    gridConstraints.insets = new Insets(10, 10, 10, 10);
	    getContentPane().add(newButton, gridConstraints);
	    newButton.addActionListener(new ActionListener()
	    {
	      public void actionPerformed(ActionEvent e)
	      {
	        newButtonActionPerformed(e);
	      }
	    });
	    getContentPane().setBackground(Color.WHITE);
	    pack();
	    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	    setBounds((int) (0.5 * (screenSize.width - getWidth())), (int) (0.5 * (screenSize.height - getHeight())), getWidth(), getHeight());
	    // start first game
	    newButton.doClick();
	  }

	  private void labelMouseClicked(MouseEvent e)
	  {
	    Component clickedComponent = e.getComponent();
	    int choice;
	    for (choice = 0; choice < 5; choice++)
	    {
	      if (clickedComponent == choiceLabel[choice][choice])
	      {
	        break;
	      }
	    }
	    choiceLabel[choice][choice].setBackground(Color.WHITE);
	    if (choice == goodLocation)
	    {
	      choiceLabel[choice][choice].setIcon(good);
	      newButton.setEnabled(true);
	    }
	  }

	  private void newButtonActionPerformed(ActionEvent e)
	  {
	    // clear boxes and hide cat
	    for (int i = 0; i < 5; i++)
	    {
	      choiceLabel[i][i].setIcon(null);
	      choiceLabel[i][i].setBackground(Color.RED);
	    }
	    goodLocation = myRandom.nextInt(5);
	    newButton.setEnabled(false);
	  }

	  private void exitForm(WindowEvent evt)
	  {
	    System.exit(0);
	  }
	}


