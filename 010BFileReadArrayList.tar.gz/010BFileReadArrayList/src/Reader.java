import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Reader {

	private static Object list;
	private static Integer sort1;
	private static String alpha = "abcdefghijklmnopqrstuvwxyz";
	private static String alpha2 = "abcdefghijklmnopqrstuvwxyz";
	static Scanner kbd = new Scanner(System.in);

	public static void main(String[] args) {
		
		
		String fileName = "/home/compsci/Documents/Text Files/Kennedy_Cuba_Crisis.txt";
		String line;
		String history = "";
		ArrayList aList = new ArrayList();
		ArrayList<Integer> letterCounter = new ArrayList <Integer> ();
		
	
		try { 
			BufferedReader input = new BufferedReader(new FileReader(fileName));
			if(!input.ready()) {
				throw new IOException();
			}
			while ((line = input.readLine()) != null) {
				aList.add(line);
			}
			input.close();
		}catch(IOException e){ 
			System.out.println("Error: " + e);
			}
		//size of list
		ArrayList count = new ArrayList();
		
		
		int sz = aList.size();
		for (int y = 0; y < alpha.length(); y++) {
			letterCounter.add(0);
			
		}
		
		for (int i = 0; i < sz; i++) {
			String line2 = aList.get(i).toString();
			for (int u = 0; u < line2.length(); u++) {
				String character = String.valueOf(line2.charAt(u));
				
			
			for (int z = 0; z < alpha.length(); z++) {
				if (character.equalsIgnoreCase(String.valueOf(alpha.charAt(z)))) {
					int sum = ((letterCounter.get(z)) + 1);
					letterCounter.set(z, sum);
					
				}
					
			}
			
			}
			
		}//end of for loop chunk
		
		for (int t = 0; t < alpha.length(); t++) {
			history = history + (String.valueOf(alpha.charAt(t)) + ":" + (letterCounter.get(t)) + " ");
		}
		
		//make into a method
		System.out.println("Type b to use bubble sort");
		String answer = kbd.nextLine();
		
		if (answer.equals( "b")) {
			System.out.println(history + "\n");
			//This is start of bubble sort
			ArrayList<Integer> lists = bubbleSort(letterCounter);
		for (int i = 0; i < lists.size() - 1; i++) {
			char letters = alpha.charAt(i);
			System.out.println(letters + ": " + (lists.get(i)));
			}
			}
		
		
		if (answer.equals( "s")) {
			
			System.out.println(history + "\n");
			//This is start of bubble sort
			ArrayList<Integer> lists = selectionSort(letterCounter);
		for (int i = 0; i < lists.size() ; i++) {
			char letters2 = alpha2.charAt(i);
			System.out.println(letters2 + ": " + (lists.get(i)));
			}

		}
		
		
		
	}//end of main
	
	
	//bubble sort
	private static ArrayList<Integer> bubbleSort (ArrayList<Integer> list) {
		int i, j, temp = 0;
		char temp2;
		for (i = 0; i < list.size() - 1; i++) {
			for( j =0; j < list.size() - 1; j++) {
				if (list.get(j) < list.get(j+1)) {
					temp = list.get(j);
					list.set(j ,list.get(j+1));
					list.set(j+1, temp);
					char[] letterStuff = alpha.toCharArray();
					temp2 = letterStuff[j];
					letterStuff[j] = letterStuff[j+1];
					letterStuff[j+1] = temp2;
					alpha = String.valueOf(letterStuff);
				}
			}
			
		}
		
		return list;
		
	}	//end of bubble sort
		//for loop for every character that test if value is the same
	
	
	//selection Sort
	private static ArrayList<Integer> selectionSort(ArrayList<Integer> list) {
		// inner loop starts at first unsorted item and continues through last item
		int i, j, minValue, minIndex, temp = 0;
		char temp3;
		for(i = 0; i< list.size() - 1; i++) {
			minValue = list.get(i);
			minIndex = i;
			for(j = i;j< list.size() ;j++) {
				if(list.get(j) > minValue) {
					minValue = list.get(j);
					minIndex = j;
				}
			}
			
			if(minValue > list.get(i)) {
				
				temp = list.get(i);
				list.set(i, list.get(minIndex));
				list.set(minIndex, temp);
				char[] letterStuff2 = alpha2.toCharArray();
				temp3 = letterStuff2[i];
				letterStuff2[i] = letterStuff2[minIndex];
				letterStuff2[minIndex] = temp3;
				alpha2 = String.valueOf(letterStuff2);
			}
		}
		
		
		
		
		return list;
	}
	
	
}

