
public class ArrayTester {
/**
 * 
 * @author Christian Galvan
 * @return 
 */
	/**
	 * Creating getColumn is first point
	 * @param arr2D
	 * @param c
	 * @return
	 */
	public static int[] getColumn(int[][] arr2D, int c)	{
		int [] result = new int[arr2D.length];
		
			for(int r = 0; r < arr2D.length; r++)
			{
				result[r] = arr2D[r][c];
			}
			return result;
		
		
	}
	
	public static boolean isLatin(int[][] square)	{
		if (containsDuplicates(square[0])) {
			return false;
		}
		for (int r = 1; r < square.length;r++) {
			if(!hasAllValues(square[0], square[r])) {
				return false;
			}
		}
		for ( int c = 0; c < square[0].length;c++) {
			if(!hasAllValues(square[0], getColumn(square, c))) {
				return false;
			}
		}
		return true;
		
		
	}
	
	
	
	private static boolean hasAllValues(int[] is1, int[] is2) {
		for (int r = 1; r < is1.length;r++) {
			if(is1.equals(is2)) {
				System.out.println();
			}
		}
		return false;
	}

	private static boolean containsDuplicates(int[] is) {
		// TODO Auto-generated method stub
		return false;
	}

	public static void main(String[] args) {
		
	}
	
	
}
