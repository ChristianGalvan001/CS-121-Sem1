package apquestion;
/**
 * 
 * @author compsci
 *
 */
public class ComplexNumber {
	/**
	 * +1 point
	 * @param real
	 * @param imagine
	 */
	private final int real;
	private final int imagine;
	
	/**
	 * +1 point
	 * @param a
	 * @param b
	 * 
	 */
	
	public ComplexNumber(int a, int b) {
		real = a;
		imagine = b;
	}

	

	public String toString() {
		if (imagine == 0) 
			return (real + "");
		if (real == 0)
			return (imagine + "i");
		if (imagine < 0) 
			return (real + " - " + (-imagine) + "i");
		
		return (real + " + " + imagine + "i");
	}
	
	/**
	 * 
	 * @param cNum
	 * @return
	 */
	public ComplexNumber add(ComplexNumber cNum) {
		ComplexNumber a = this;
		int real = (a.real + cNum.real);
		int imagine = (a.imagine + cNum.imagine);
		
		return new ComplexNumber(real, imagine);
	}
	
	/**
	 * +5 points by multiplying and adding components; returns ComplexNumber object;implements accessors
	 * @param cNum
	 * @return
	 */
	public ComplexNumber multiply(ComplexNumber cNum) {
		ComplexNumber a = this;
		int real = (a.real * cNum.real - a.imagine * cNum.imagine);
		int imagine = (a.real * cNum.imagine + a.imagine * cNum.real);
		
		return new ComplexNumber(real, imagine);
	}
	
	/**
	 * +1 point for both getters
	 * @return
	 */
	public int getA(){
		return real;
	}
	
	public int getB(){
		return imagine;
	}
	
	
	
	public static void main(String[] args) {
		ComplexNumber a = new ComplexNumber(3, 6);
		ComplexNumber b = new ComplexNumber(-4, 2);
		
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("--------------------------------");
		System.out.println("addition = " + b.add(a));
		System.out.println("Multiply = " + a.multiply(b));
		
		System.out.println("\n\n");
		
		a = new ComplexNumber(2, 4);
		b = new ComplexNumber(3, -5);
		
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("--------------------------------");
		System.out.println("addition = " + b.add(a));
		System.out.println("Multiply = " + a.multiply(b));

	}//end of main

}//end of class
