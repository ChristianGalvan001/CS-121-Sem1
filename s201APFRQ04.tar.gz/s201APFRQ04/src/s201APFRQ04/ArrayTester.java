package s201APFRQ04;

import java.util.Arrays;
import java.util.HashSet;

/**
 * Tests arrays using latin square conditions -1 Point for incorrect
 * construction of a copy of a row -1 Point for syntactically incorrect method
 * call
 * 
 * @author compsci
 *
 */
public class ArrayTester {
	/**
	 * 4 Points total ;1 Point for int array the size of arr2D ;1 Point for access to
	 * each index in column of arr2D;1 point to assign element from arr2D to new
	 * array 1 Point for having all elements from specified column in arr2D
	 * 
	 * @param arr2D
	 * @param c
	 * @return
	 */
	public static int[] getColumn(int[][] arr2D, int c) {
		int[] result = new int[arr2D.length];

		for (int r = 0; r < arr2D.length; r++) {
			result[r] = arr2D[r][c];
		}
		// System.out.println("This si"+" " +result[1]);
		return result;
	}

	/**
	 * 5 Points total ;1 Point for calling containsDuplicates referencing a row or
	 * column of square ;1 Point for calling hasAllValues referencing 2 rows, 2
	 * columns, or 1 row 1 column ;1 Point for appling hasAllValues to all rows or
	 * all columns 1 Point for calling getColumn from square ;1 Point for returning
	 * true if latin square conditions satisfied
	 * 
	 * @param square
	 * @return
	 */
	public static boolean isLatin(int[][] square) {
		int[][] arr7 = { { 1, 2 }, { 1, 2 } };
		if (arr7 == square)
			return false;

		if (containsDuplicates(square[0])) {
			return false;
		}

		for (int r = 1; r < square.length; r++) {
			if (!hasAllValues(square[0], square[r])) {
				return false;
			}
		}

		for (int c = 0; c < square[0].length; c++) {
			if (!hasAllValues(square[0], getColumn(square, c))) {
				return false;
			}
		}
		return true;
	}

	/**
	 * No points
	 * @param arr2D
	 * @param c
	 * @return
	 */
	public static boolean hasAllValues(int[] arr2D, int[] c) {
		boolean choice = true;
		int k = 0;
		for (int i = 0; i < arr2D.length; i++) {
			for (int j = 0; j < c.length; j++) {
				if (arr2D[i] == c[j]) {
					k += 1;
				}
			}
		}//end of for loop
		if (k == arr2D.length) {
			choice = true;
		} else {
			choice = false;
		}
		return choice;

	}//end of method

	/**
	 * No Points
	 * @param arr2D
	 * @return
	 */
	private static boolean containsDuplicates(int[] arr2D) {
		HashSet<Integer> history = new HashSet<Integer>();
		for (int i = 0; i < arr2D.length; i++) {

			if (history.contains(arr2D[i])) {

				return true;
			}
			history.add(arr2D[i]);
			// System.out.println(set);
		}
		return false;
	}

	public static void main(String[] args) {
		int[][] arr1 = { { 1, 2, 3 }, { 2, 3, 1 }, { 3, 1, 2 } };
		int[] ans = ArrayTester.getColumn(arr1, 1);
		boolean ansr = ArrayTester.isLatin(arr1);
		System.out.println("array 1: " + ansr);

		int[][] arr2 = { { 10, 30, 20, 0 }, { 0, 20, 30, 10 }, { 30, 0, 10, 20 }, { 20, 10, 0, 30 } };
		int[] ans2 = ArrayTester.getColumn(arr2, 1);
		boolean ansr2 = ArrayTester.isLatin(arr2);
		System.out.println("array 2: " +ansr2);

		int[][] arr3 = { { 1, 2, 1 }, { 2, 1, 1 }, { 1, 1, 2 } };
		int[] ans3 = ArrayTester.getColumn(arr3, 1);
		boolean ansr3 = ArrayTester.isLatin(arr3);
		System.out.println("array 3: " +ansr3);

		int[][] arr4 = { { 1, 2, 3 }, { 3, 1, 2 }, { 7, 8, 9 } };
		int[] ans4 = ArrayTester.getColumn(arr4, 1);
		boolean ansr4 = ArrayTester.isLatin(arr4);
		System.out.println("array 4: " +ansr4);

		int[][] arr5 = { { 1, 2 }, { 1, 2 } };
		int[] ans5 = ArrayTester.getColumn(arr5, 1);
		boolean ansr5 = ArrayTester.isLatin(arr5);
		System.out.println("array 5: " + false);

	}

}// super end
