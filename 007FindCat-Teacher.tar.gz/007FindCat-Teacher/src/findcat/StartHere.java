package findcat;


public class StartHere {

	public static void main(String[] args) {
		FindCat myTreasure = new FindCat();
		myTreasure.setVisible(true);
	}

}
