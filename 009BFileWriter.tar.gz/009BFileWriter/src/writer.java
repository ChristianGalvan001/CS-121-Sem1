
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

public class writer {
	public static void main(String[] args) throws FileNotFoundException {
		PrintWriter out = new PrintWriter("/home/compsci/Documents/Text Files/output.txt");
		for (int i = 0; i <= 10 ; i++	 ) { 
			out.println(i);

		}
		out.close();
	}
}
