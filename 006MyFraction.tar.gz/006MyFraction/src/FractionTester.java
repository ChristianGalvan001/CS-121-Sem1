import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * 
 * Add two fractions. Learn Javadocs. Enter the two fractions as Strings 
 * then use String methods to pull our numerator and denominator.
 * Use common denominator to add, then reduce to lowest common denominator
 * (first part of grading)
 * Then add, subtract, multiply, divide with javadocs
 * 
 * @author Christian Galvan
 *
 */

	
public class FractionTester {
	static String answer;
	static String answer1;
	public static void main(String[] args) {
		
		ask();
		Fraction myFraction = new Fraction(answer, answer1);
		JOptionPane.showMessageDialog(null, 
		"Addition:            " + myFraction.addFraction() +"\n" + 
		"Subtraction:      " + myFraction.subtractFraction() + "\n" +
		"Multiplication:   " + myFraction.MultiplyFraction() + "\n" + 
		"Division:             " + myFraction.DivideFraction());
		
	}
	
	
	
	
	
	
	
	
	
	
	/*
	 * Asks the user for two fractions. 
	 * Uses array as for JOptionPane to ask for the numerator and denominator for both fractions.
	 * This will get returned and passed as a parameter for myFraction
	 * 
	 */
	
	public static String ask() {
		int fraction1;
		int fraction2;
		
		
		JTextField field1 = new JTextField();
		JTextField field2 = new JTextField();
		JTextField field3 = new JTextField();
		JTextField field4 = new JTextField();
		
		Object[] fields = {
				"Numerator1", field1,
				"Denominator1", field2,
				"Numerator2", field3,
				"Denominator2", field4
		};
		
	
			fraction1 = JOptionPane.showConfirmDialog(null, fields, "Fractions", JOptionPane.OK_CANCEL_OPTION);	
			answer = (field1.getText() + "/" + field2.getText());
			answer1 = (field3.getText() + "/" + field4.getText());
			return(answer);
	}

}
