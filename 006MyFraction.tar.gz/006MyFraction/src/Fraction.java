import javax.swing.JOptionPane;
import javax.swing.JTextField;

/*
 * Overload - same name, different pass parameters
 * substring and indexOf
 * grade requirements: Fraction Add
 * string inputs "13/64"
 * num/den2 + num2/den2
 * jops
 */


public class Fraction {
	//field
	private int denominatorFactored;
	private int numeratorMul1;
	private int numeratorMul2;
	private int finaladd;
	private int finalsubtract;
	private int numerator;
	private int denominator;
	private int numerator2;
	private int denominator2;
	private int finalMultiply;
	private String finalAnswerDivide2;
	private String finalAnswerMultiply2;
	private String finalAnswerSubtract2;
	private String finalAnswer2;

	
	
	
	//field
	
	//constructer
	
	
	/*
	 * This separates both of the fractions given by the user.
	 * Uses "/" to separate the fractions
	 * Creates two numerator and two denominators
	 */
	public Fraction(String passFraction, String passFraction2) {
		int separatorLocation = passFraction.indexOf("/");
		int separatorLocation2 = passFraction2.indexOf("/");
		String strNumerator = passFraction.substring(0,
				separatorLocation);
		String strNumerator2 = passFraction2.substring(0,
				separatorLocation2);
		String strDenominator = passFraction
				.substring(separatorLocation + 1);
		String strDenominator2 = passFraction2
				.substring(separatorLocation2 + 1);

		this.numerator = Integer.parseInt(strNumerator);
		this.numerator2 = Integer.parseInt(strNumerator2);
		this.denominator = Integer.parseInt(strDenominator);
		this.denominator2 = Integer.parseInt(strDenominator2);
	}
	

	
	//constructer
	
	//methods
	
	
	
	public int getNumerator() {
		return numerator;
	}
	public int getNumerator2() {
		return numerator2;
	}

	public void setNumerator(int numerator) {
		this.numerator = numerator;
	}

	public int getDenominator() {
		return denominator;
	}
	public int getDenominator2() {
		return denominator2;
	}

	public void setDenominator(int denominator) {
		this.denominator = denominator;
	}
	
	/*
	 * This adds two fractions
	 * multiplies both denominators
	 * multiplies first numerator by second denominator 
	 * multiplies second numerator by first denominator
	 * Then adds both numerators
	 * asFraction() method simplifies the fraction
	 */
	public String addFraction() {
		
		denominatorFactored = (getDenominator() * getDenominator2()); //"GCF of denominator: " 
		numeratorMul1 = ((getNumerator() * getDenominator2())); //"GCF of numerator1: " 
		numeratorMul2 = ((getNumerator2() * getDenominator())); //"GCF of numerator2: "
		finaladd = (numeratorMul1 + numeratorMul2);
		finalAnswer2 = asFraction(finaladd, denominatorFactored);
		return(finalAnswer2);
	}
	/*
	 * This adds two fractions
	 * multiplies both denominators
	 * multiplies first numerator by second denominator 
	 * multiplies second numerator by first denominator
	 * Then subtracts both numerators
	 * asFraction() method simplifies the fraction
	 */
	public String subtractFraction() {
		
		denominatorFactored = (getDenominator() * getDenominator2()); //"GCF of denominator: " 
		numeratorMul1 = ((getNumerator() * getDenominator2())); //"GCF of numerator1: " 
		numeratorMul2 = ((getNumerator2() * getDenominator())); //"GCF of numerator2: "
		finalsubtract = (numeratorMul1 - numeratorMul2);
		finalAnswerSubtract2 = asFraction(finalsubtract, denominatorFactored);
		return(finalAnswerSubtract2);
	}
	
	/*
	 * This multiplies two fractions
	 * multiplies both denominators
	 * multiplies first numerator by second numerator
	 * asFraction() method simplifies the fraction
	 */
public String MultiplyFraction() {
		
		denominatorFactored = (getDenominator() * getDenominator2()); //"GCF of denominator: " 
		numeratorMul1 = ((getNumerator() * getNumerator2())); //"GCF of numerator1: " 
		finalAnswerMultiply2 = asFraction(numeratorMul1, denominatorFactored);
		return(finalAnswerMultiply2);
	}

/*
 * This divides two fractions
 * multiplies first numerator by second denominator
 * multiplies first denominator by second numerator
 * asFraction() method simplifies the fraction
 */
public String DivideFraction() {
	
	numeratorMul1 = (getNumerator() * getDenominator2()); //"GCF of denominator: " 
	denominatorFactored = ((getDenominator() * getNumerator2())); //"GCF of numerator1: " 
	finalAnswerDivide2 = asFraction(numeratorMul1, denominatorFactored);
	return(finalAnswerDivide2);
}
 /*
  * This finds the greatest common multiple
  * passes two parameters - numerator and denominator
  * finds the modulus - if it is equal denominator is equal to zero it returns the gcm
  */
public static long gcm(long a, long b) {
	return b == 0 ? a :gcm(b, a % b);
}

/*
 * This returns the simplified fraction]
 * uses gcm method to divide the numerator and denominator by the gcm
 */
public static String asFraction(long a , long b) {
	long gcm = gcm(a, b);
	return (a/ gcm) + "/" + (b / gcm);
}




	
	


	
	
	
	

	//methods

}
