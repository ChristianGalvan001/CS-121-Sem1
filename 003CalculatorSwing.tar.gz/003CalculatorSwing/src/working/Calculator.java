package working;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
	
	public class Calculator implements ActionListener {
		//class vars
		JFrame frame;
		JTextField textField;
		JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,bdec,badd,bsub,
		bmul,bdiv,beq,bclr,bksp,bsqr,bcbe,bsqt,blog;
		
		Double firstNumber, secondNumber, result;
		int operator;
		
		
		
		Calculator() { 
			frame = new JFrame("Calculator, Created by Christian G.");
			frame.setLayout(null);
			
			
			textField = new JTextField();
			textField.setBounds(30, 40,410,30);
			frame.add(textField);
			
			frame.setSize(700, 600);;
			frame.setVisible(true);
			
			
			b1 = new JButton("1");
			b1.setBounds(40,240,50,40);
			b1.setBackground(Color.ORANGE);
			frame.add(b1);
	
			b2 = new JButton("2");
			b2.setBounds(110,240,50,40);
			b2.setBackground(Color.ORANGE);
			frame.add(b2);
			
			b3 = new JButton("3");
			b3.setBounds(180,240,50,40);
			b3.setBackground(Color.ORANGE);
			frame.add(b3);
			
			b4 = new JButton("4");
			b4.setBounds(40,170,50,40);
			b4.setBackground(Color.ORANGE);
			frame.add(b4);
			
			b5 = new JButton("5");
			b5.setBounds(110,170,50,40);
			b5.setBackground(Color.ORANGE);
			frame.add(b5);
			
			
			b6 = new JButton("6");
			b6.setBounds(180,170,50,40);
			b6.setBackground(Color.ORANGE);
			frame.add(b6);
			
			
			
			b7 = new JButton("7");
			b7.setBounds(40,100,50,40);
			b7.setBackground(Color.ORANGE);
			frame.add(b7);
			
			b8 = new JButton("8");
			b8.setBounds(110,100,50,40);
			b8.setBackground(Color.ORANGE);
			frame.add(b8);
			
			b9 = new JButton("9");
			b9.setBounds(180,100,50,40);
			b9.setBackground(Color.ORANGE);
			frame.add(b9);
			
			b0 = new JButton("0"); 
			b0.setBounds(180,300,50,40);
			b0.setBackground(Color.ORANGE);
			frame.add(b0);
			
			beq = new JButton("="); 
			beq.setBounds(110,300,50,40);
			beq.setBackground(Color.CYAN);
			frame.add(beq);
			
			bdec = new JButton("."); 
			bdec.setBounds(40,300,50,40);
			bdec.setBackground(Color.CYAN);
			frame.add(bdec);
			
			bsub = new JButton("-"); 
			bsub.setBounds(250,240,50,40);
			bsub.setBackground(Color.CYAN);
			frame.add(bsub);
			
			bsqr = new JButton("sqr"); 
			bsqr.setBounds(320,240,70,40);
			bsqr.setBackground(Color.GREEN);
			frame.add(bsqr);
			
			bmul = new JButton("*"); 
			bmul.setBounds(250,170,50,40);
			bmul.setBackground(Color.CYAN);
			frame.add(bmul);
			
			bcbe = new JButton("cube"); 
			bcbe.setBounds(320,170,70,40);
			bcbe.setBackground(Color.GREEN);
			frame.add(bcbe);
			
			bdiv = new JButton("/"); 
			bdiv.setBounds(250,100,50,40);
			bdiv.setBackground(Color.CYAN);
			frame.add(bdiv);
			
			bsqt = new JButton("sqr root"); 
			bsqt.setBounds(320,100,100,40);
			bsqt.setBackground(Color.GREEN);
			frame.add(bsqt);
			
			bclr = new JButton("Clear"); 
			bclr.setBounds(40,380,100,40);
			bclr.setBackground(Color.CYAN);
			frame.add(bclr);
			
			bksp = new JButton("Backspace"); 
			bksp.setBounds(180,380,150,40);
			bksp.setBackground(Color.CYAN);
			frame.add(bksp);
			
			badd = new JButton("+");
			badd.setBounds(250,300,50,40);
			badd.setBackground(Color.CYAN);
			frame.add(badd);
			
			blog = new JButton("log");
			blog.setBounds(320,300,70,40);
			blog.setBackground(Color.GREEN);
			frame.add(blog);
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setResizable(false);
			frame.setSize(800, 600);
			frame.setVisible(true);
			
			b1.addActionListener(this);
			b2.addActionListener(this);
			b3.addActionListener(this);
			b4.addActionListener(this);
			b5.addActionListener(this);
			b6.addActionListener(this);
			b7.addActionListener(this);
			b8.addActionListener(this);
			b9.addActionListener(this);
			b0.addActionListener(this);
			bdec.addActionListener(this);
			badd.addActionListener(this);
			bsub.addActionListener(this);
			bmul.addActionListener(this);
			bdiv.addActionListener(this);
			beq.addActionListener(this);
			bclr.addActionListener(this);
			bksp.addActionListener(this);
			bsqr.addActionListener(this);
			bcbe.addActionListener(this);
			bsqt.addActionListener(this);
			blog.addActionListener(this);
			
			
			
			
			
		}
		
		
		
		//listener
		@Override
		public void actionPerformed(ActionEvent e) {
			//handler
			if(e.getSource() == b1)
				textField.setText(textField.getText().concat("1"));
			if(e.getSource() == b2)
				textField.setText(textField.getText().concat("2"));
			if(e.getSource() == b3)
				textField.setText(textField.getText().concat("3"));
			if(e.getSource() == b4)
				textField.setText(textField.getText().concat("4"));
			if(e.getSource() == b5)
				textField.setText(textField.getText().concat("5"));
			if(e.getSource() == b6)
				textField.setText(textField.getText().concat("6"));
			if(e.getSource() == b7)
				textField.setText(textField.getText().concat("7"));
			if(e.getSource() == b8)
				textField.setText(textField.getText().concat("8"));
			if(e.getSource() == b9)
				textField.setText(textField.getText().concat("9"));
			if(e.getSource() == b0)
				textField.setText(textField.getText().concat("0"));
			if(e.getSource() == bdec)
				textField.setText(textField.getText().concat("."));
			
			if(e.getSource() == bclr) {
				textField.setText("");
				}
			if(e.getSource() == beq) {
				secondNumber = Double.parseDouble(textField.getText());
				
				switch(operator) {
				case 1:
					result = firstNumber + secondNumber;
					break;
				case 2:
					result = firstNumber - secondNumber;
					break;
				case 3:
					result = firstNumber * secondNumber;
					break;
				case 4: 
					result = firstNumber / secondNumber;
					break;
				case 5:
					result = Math.pow(firstNumber, 2.0);
					break;
				case 6:
					result = Math.pow(firstNumber, 3.0);
					break;
				case 7:
					result = Math.log10(firstNumber);
					break;
				case 8:
					result = Math.sqrt(firstNumber);
					break;
					
				default: result = 0.0;
				}
					textField.setText("" + result);
				}
			if(e.getSource() == badd) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 1;
				textField.setText("");
				}
			if(e.getSource() == bsub) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 2;
				textField.setText("");
				}
			if(e.getSource() == bmul) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 3;
				textField.setText("");
				}
			if(e.getSource() == bdiv) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 4;
				textField.setText("");
				}
			if(e.getSource() == bksp) {
				//s is what was in the text field
				String s=textField.getText();
				//clear text field
				textField.setText("");
				//for every character in s minus one
				for (int i = 0; i<s.length()-1;i++)
					//add that character from s into the text field. character a pos i
					textField.setText(textField.getText()+s.charAt(i));
			}
			if(e.getSource() == bsqr) {
				//firstNumber = Double.parseDouble(textField.getText());
				//operator = 5;
				//textField.setText("");
				
				boolean b = true;
				while (b) {
				try {	
				firstNumber = Double.parseDouble(textField.getText());
				operator = 5;
				
				b = false;
				} catch (Exception e1) {
				
				b = false;
				}//catch
						}//while
				
				}
			if(e.getSource() == bcbe) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 6;
				
				}
			if(e.getSource() == blog) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 7;
				
				}
			if(e.getSource() == bsqt) {
				firstNumber = Double.parseDouble(textField.getText());
				operator = 8;
				
				}
			/*
			
			if(e.getSource() == badd)
				textField.setText(textField.getText().concat("9"));
			if(e.getSource() == b9)
				textField.setText(textField.getText().concat("9"));
			if(e.getSource() == b9)
				textField.setText(textField.getText().concat("9"));
			if(e.getSource() == b9)
				textField.setText(textField.getText().concat("9"));
			if(e.getSource() == b9)
				textField.setText(textField.getText().concat("9"));
			
				
			*/
			
			
		}
		//handler methods
		
		
	}//end of calculator


