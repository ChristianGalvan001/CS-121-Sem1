import java.util.ArrayList;

public class RandomStringChooser extends Main {
	
	private ArrayList<String> wordThing = new ArrayList<String>();
	
	public RandomStringChooser(String[] wordArray) {
		
	}
	
    
	public String getNext() {
		String word;
		String[] wordArray = {"wheels", "on", "the", "bus"};
		double randomNum = Math.floor(Math.random() * wordArray.length);
		word = wordArray[(int)randomNum];
		if(wordThing.contains(word)) {
			return "none";
		}
		wordThing.add(word);
		return word;
	}
	
	
	
	
	
	
	

}
