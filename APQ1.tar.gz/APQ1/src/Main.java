
public class Main {
	
	public static void main(String[] args) {
		
		String[] wordArray = {"wheels", "on", "the", "bus"};
		RandomStringChooser sChooser = new RandomStringChooser(wordArray);
		for (int k = 0; k < wordArray.length; k++)
		{
			System.out.println(sChooser.getNext() +  " ");
		}
		}
}
