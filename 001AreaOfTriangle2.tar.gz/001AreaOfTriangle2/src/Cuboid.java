import javax.swing.JOptionPane;


public class Cuboid {
	
	private double sideA, sideB, sideC;
	private double volume, surfaceArea;
	
	public void setVarsToZero() {
		double sideA = 0.00;
		double sideB = 0.00;
		double perimeter = 0.00;
		double area = 0.00;
	}
	
	public void setSides() {

		sideA = Double.parseDouble(JOptionPane.showInputDialog("Please enter the length of side A (Width): "));

		sideB = Double.parseDouble(JOptionPane.showInputDialog("Please enter the length of side B (Length): "));
		
		sideC = Double.parseDouble(JOptionPane.showInputDialog("Please enter the length of side C (Height): "));
	}//set sides
	
	public void calcVolume() {
		//2(l+w)
		volume =  sideA * sideB * sideC;
		JOptionPane.showMessageDialog(null, "Volume: " + volume); 
		
	}
	
	public void calcSurfaceArea() {
		//2(l+w)
		surfaceArea = 2 * ((sideA * sideB) + (sideB * sideC) + (sideA * sideC));
		JOptionPane.showMessageDialog(null, "Surface Area: " + surfaceArea); 
		
	}
}
