import javax.swing.JOptionPane;

public class Sphere {

	private double radius;
	private double circumference, surfaceArea, volume;
	
	public void setVarsToZero() {
		double radius = 0.00;
		double circumference = 0.00;
		double surfaceArea = 0.00;
		double volume = 0.00;
	}
	
	public void setRadius() {
		boolean b = true;
		while (b) {
		try {	
		radius = Double.parseDouble(JOptionPane.showInputDialog("Please enter the radius of the Sphere (integer): "));
		b = false;
		} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Please Enter A number");	
		}//catch
				}//while
		
	}//set sides
	
	public void calcVolume() {

		volume =  (4.0/3.0) * Math.PI * Math.pow(radius, 3.0);
		JOptionPane.showMessageDialog(null, "Volume: " + volume); 
		
	}
	
	public void calcSurfaceArea() {
	
		surfaceArea = 4 * Math.PI * Math.pow(radius, 2);
		JOptionPane.showMessageDialog(null, "Surface Area: " + surfaceArea); 
		
	}	
	
}
