import javax.swing.JOptionPane;

public class Circle {
	
	private double radius;
	private double circumference, area;
	
	public void setVarsToZero() {
		double radius = 0.00;
		double circumference = 0.00;
		double area = 0.00;
	}
	
	public void setSides() {
		boolean b = true;
		while (b) {
		try {	
		radius = Double.parseDouble(JOptionPane.showInputDialog("Please enter the radius of the circle (integer): "));
		b = false;
		} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Please Enter A number");	
		}//catch
				}//while
		
	}//set sides
	
	public void calcCircumference() { 
		boolean b = true;
		while (b) {
		try {	
			circumference = 2 * Math.PI * radius;
			b = false;
		} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Please Enter A number");	
		}//catch
				}//while
		
		JOptionPane.showMessageDialog(null, "Circumference " + circumference);
	}
	
	public void calcArea() { 
		area = Math.PI * Math.pow(radius, 2);
		JOptionPane.showMessageDialog(null, "Area: " + area);
	}
	

}
