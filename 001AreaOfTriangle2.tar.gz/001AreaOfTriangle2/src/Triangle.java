import java.text.DecimalFormat;
import java.util.Scanner;

import javax.swing.JOptionPane;

//private can only be used in that class
//float is a special kind of double(how you do decimal points)
// syso alt space

public class Triangle {

	// class variables go here
	private double sideA, sideB, sideC;
	private double perimeter;
	private double theArea;
	private double p;
	
	
	
	// contructor goes here |*where the class begins*| *always public*
	public Triangle() {
		
		setVarsToZero();
	}

	public void setVarsToZero() {
		sideA = 0.0;
		sideB = 0.0;
		sideC = 0.0;
		perimeter = 0.0;
		p = 0.0;
		theArea = 0.0;
	    
    }// End of setVarsToZero
	
	public void showVars() {
		DecimalFormat df = new DecimalFormat("###.###");
		String msg = 
				"Side A, B, C = " + sideA + ", " +  sideB + ", " +  sideC + 
				" ; perimeter: " + perimeter
				+ ": area = " + df.format(theArea);
		
		JOptionPane.showMessageDialog(null, msg); 
		System.out.println(" ");
		
	}//End of showVars
	
	public void setSides() {
		boolean b = true;
		while (b) {
		try {
			sideA = Double.parseDouble(JOptionPane.showInputDialog("Please enter the length of side A (integer): "));
			b = false;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Please Enter A number");
		}
		
		b = true;
		
		try {
			sideB = Double.parseDouble(JOptionPane.showInputDialog("Please enter the length of side B (integer): "));
			b = false;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Please Enter A number");
		}
		
		
		b = true;
		
		try {
			sideC = Double.parseDouble(JOptionPane.showInputDialog("Please enter the length of side C (integer): "));
			b = false;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Please Enter A number");
		}
				
		
	}//while
	}//set sides

	
	
	// methods go here




	public void calculatePerimeter() {
		// TODO Auto-generated method stub
		perimeter = (sideA+sideB+sideC)/2;
		
	}
	
	public void calcArea(){
		double p = (sideA+sideB+sideC) / 2;
		theArea = Math.sqrt(p * (p - sideA) * (p -sideB) * (p -sideC));
	}
	
	public void calcAngles(){
		double cosC = 0.0,  Bcos= 0.0;
		double cosA = 0.0,	Acos= 0.0;
		double cosB = 0.0,	Ccos= 0.0;
		double Adeg = 0.0, Bdeg = 0.0, Cdeg = 0.0;
		
		
		cosA = (Math.pow(sideB, 2.0) + Math.pow(sideC, 2.0) - Math.pow(sideA, 2.0))/
				(2.0 * sideB * sideC); 
		Acos = Math.acos(cosA);
		Adeg = Math.toDegrees(Acos); 

		
		cosB = (Math.pow(sideC, 2.0) + Math.pow(sideA, 2.0) - Math.pow(sideB, 2.0))/
				(2.0 * sideC * sideA); 
		Bcos = Math.acos(cosB);
		Bdeg = Math.toDegrees(Bcos);

		
		cosC = (Math.pow(sideA, 2.0) + Math.pow(sideB, 2.0) - Math.pow(sideC, 2.0))/
				(2.0 * sideA * sideB); 
		Ccos = Math.acos(cosC);
		Cdeg = Math.toDegrees(Ccos);
		
		DecimalFormat df = new DecimalFormat("###.###");

		JOptionPane.showMessageDialog(null, "Angle a: " + df.format(Adeg) + " Angle B: " + df.format(Bdeg) + " Angle C: " + df.format(Cdeg));

	}
	
	public void showVarsAngles(){
		
	}
	
}
