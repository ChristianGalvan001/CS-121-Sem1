
import javax.swing.JOptionPane;


public class Runner{
	/***************************************************************
	 * 
	 * Circle: input r, calculate circumference, area
	 * Rectangle: input side A, B, calc perimeter, area, and diagonal
	 * Triangle: input sides A, B, C, calc perimeter, area, all angles
	 * Cuboid: input sides A, B, C, calc volume, total surface area
	 * Sphere: input radius, calc volume, and surface area
	 * Total celebration dance
	 *
	 *
	 */

	public static void main(String[] args) {
		
		//JOptionPane.showMessageDialog(null, "Hello, Welcome to my lair!" + " Take off your shoes!");
		
		// Insantiate each class
		Triangle myTriangle = new Triangle();
		Rectangle myRectangle = new Rectangle();
		Circle myCircle = new Circle();
		Sphere mySphere = new Sphere();
		Cuboid myCuboid = new Cuboid();
		
		
		int goAgain = 1;
		
		
		while(goAgain == 1) {
		String msg = "Please enter your selection: Triangle, Circle, Rectangle, Cuboid, Sphere.";
		
		String answer = JOptionPane.showInputDialog(msg);
		JOptionPane.showMessageDialog(null, answer);
		
		// When comparing strings == is unreliable
		
		if ((answer.equals("Triangle")) || (answer.equals("triangle"))) {
			myTriangle.setVarsToZero();
			myTriangle.setSides();
			myTriangle.calculatePerimeter();
			myTriangle.calcArea();
			myTriangle.showVars();
			myTriangle.calcAngles();
			myTriangle.showVarsAngles();
		}//triangle -----------------------------------------------------------------------------------
		
		
		else if ((answer.equals("Circle")) || (answer.equals("circle"))) {
			myCircle.setVarsToZero();
			myCircle.setSides();
			myCircle.calcCircumference();
			myCircle.calcArea();
		}//circle -----------------------------------------------------------------------------------
		
		
		else if ((answer.equals("Rectangle")) || (answer.equals("rectangle"))) {
			myRectangle.setVarsToZero();
			myRectangle.setSides();
			myRectangle.calcPerimeter();
			myRectangle.calcArea();
		}//rectangle -----------------------------------------------------------------------------------
		
		
		else if ((answer.equals("Cuboid")) || (answer.equals("cuboid"))) {
			myCuboid.setVarsToZero();
			myCuboid.setSides();
			myCuboid.calcVolume();
			myCuboid.calcSurfaceArea();
		}//cuboid -----------------------------------------------------------------------------------
		
		
		else if ((answer.equals("Sphere")) || (answer.equals("sphere"))) {
			mySphere.setVarsToZero();
			mySphere.setRadius();
			mySphere.calcVolume();
			mySphere.calcSurfaceArea();
		}//sphere -----------------------------------------------------------------------------------
		
		
		else {
			JOptionPane.showMessageDialog(null, "wrong");
		}//else -----------------------------------------------------------------------------------
		
		
		
		msg = "Would you like to go again?";
		
		answer = JOptionPane.showInputDialog(msg);
		
		if((answer.equals("Yes")) || (answer.equals("yes")) || (answer.equals("y"))) {
			goAgain = 1;
		}
		else {
			goAgain = 0;
			JOptionPane.showMessageDialog(null, "Thank you! See you next time.");
		}
		
		}//while
		
	}//main
}//runner

