import javax.swing.JOptionPane;

public class Rectangle {
		
		private double sideA, sideB;
		private double perimeter, area;
		
		public void setVarsToZero() {
			double sideA = 0.00;
			double sideB = 0.00;
			double perimeter = 0.00;
			double area = 0.00;
		}
		
		public void setSides() {

			sideA = Double.parseDouble(JOptionPane.showInputDialog("Please enter the length of side A (integer): "));

			sideB = Double.parseDouble(JOptionPane.showInputDialog("Please enter the length of side B (integer): "));
		}//set sides
		
		public void calcPerimeter() {
			//2(l+w)
			perimeter = 2 * (sideA + sideB);
			JOptionPane.showMessageDialog(null, "Perimeter: " + perimeter); 
			
		}
		
		public void calcArea() {
			//2(l+w)
			area = sideA * sideB;
			JOptionPane.showMessageDialog(null, "Area: " + area); 
			
		}
		
}//rectangle
