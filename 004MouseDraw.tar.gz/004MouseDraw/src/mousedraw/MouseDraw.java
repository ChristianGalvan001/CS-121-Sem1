package mousedraw;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * 
 * extends makes it so you dont have to do JFrame.(etc) Only can extend one
 * class (c++ can have more = more crashes) can still implement or stack
 * 
 */
public class MouseDraw extends JFrame {

	// top bar with the lists
	JMenuBar mainMenuBar = new JMenuBar();
	// list
	JMenu fileMenu = new JMenu("File");
	JMenu fileMenu2 = new JMenu("BoardColor");
	JMenu fileMenu3 = new JMenu("PenSize");
	JMenuItem blackMenuItem = new JMenuItem("Black");
	JMenuItem yellowMenuItem = new JMenuItem("Yellow");
	JMenuItem redMenuItem = new JMenuItem("Red");
	JMenuItem fineMenuItem = new JMenuItem("Fine");
	JMenuItem smallMenuItem = new JMenuItem("Small");
	JMenuItem mediumMenuItem = new JMenuItem("Medium");
	JMenuItem largeMenuItem = new JMenuItem("Large");
	JMenuItem newMenuItem = new JMenuItem("New");
	JMenuItem exitMenuItem = new JMenuItem("Exit");

	Graphics2D g2D;
	double xPrevious, yPrevious;

	Color drawColor, leftColor, rightColor;
	JPanel drawPanel = new JPanel();

	JLabel leftColorLabel = new JLabel();
	JLabel rightColorLabel = new JLabel();

	JPanel colorPanel = new JPanel();
	JLabel[] colorLabel = new JLabel[18];

	public MouseDraw() {
		setTitle("Art by Christian Galvan");
		setResizable(false);
		// setSize(800, 600);

		/*
		 * addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent
		 * e) { exitForm(e); } }); // windowlistener
		 */
		// makes it easy to resize
		getContentPane().setLayout(new GridBagLayout());

		setJMenuBar(mainMenuBar);
		fileMenu.setMnemonic('F');

		mainMenuBar.add(fileMenu);
		mainMenuBar.add(fileMenu2);
		mainMenuBar.add(fileMenu3);
		fileMenu.add(newMenuItem);
		fileMenu.addSeparator();
		fileMenu.add(exitMenuItem);

		fileMenu2.setMnemonic('B');
		fileMenu2.add(blackMenuItem);
		fileMenu2.add(yellowMenuItem);
		fileMenu2.add(redMenuItem);

		fileMenu3.setMnemonic('P');
		fileMenu3.add(fineMenuItem);
		fileMenu3.add(smallMenuItem);
		fileMenu3.add(mediumMenuItem);
		fileMenu3.add(largeMenuItem);

		drawPanel.setPreferredSize(new Dimension(500, 400));
		drawPanel.setBackground(new Color(200, 200, 200)); // RGB 0-255
		
		newMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				newMenuItemActionPerformed(e);
			}

		});
		
		blackMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				blackMenuItemActionPerformed(e);
			}

		});
		
		yellowMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				yellowMenuItemActionPerformed(e);
			}

		});
		
		redMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				redMenuItemActionPerformed(e);
			}

		});
		
		fineMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				fineMenuItemActionPerformed(e);
			}

		});
		
		smallMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				smallMenuItemActionPerformed(e);
			}

		});
		
		mediumMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				mediumMenuItemActionPerformed(e);
			}

		});
		
		largeMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				largeMenuItemActionPerformed(e);
			}

		});

		
		/* exitMenuItem.addActionListener(new ActionListener() { public void
		 actionPerformed(ActionEvent e) {
		  
		  exitMenuItemActionPerformed(e); } }); */
		 

		drawPanel.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {

				drawPanelMousePressed(e);
			}
		});

		drawPanel.addMouseMotionListener(new MouseMotionAdapter() {
			public void mouseDragged(MouseEvent e) {

				drawPanelDragged(e);
			}

		});

		drawPanel.addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent e) {

				drawPanelMouseReleased(e);
			}
		});

		drawPanel.setPreferredSize(new Dimension(500, 400));
		drawPanel.setBackground(Color.LIGHT_GRAY);

		GridBagConstraints gridConstraints = new GridBagConstraints();
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 0;
		gridConstraints.gridheight = 2;
		gridConstraints.insets = new Insets(10, 10, 10, 10);
		getContentPane().add(drawPanel, gridConstraints);

		leftColorLabel.setPreferredSize(new Dimension(40, 40));
		leftColorLabel.setOpaque(true);
		leftColorLabel.setBackground(Color.YELLOW);
		gridConstraints = new GridBagConstraints();
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 0;
		gridConstraints.anchor = GridBagConstraints.NORTH;
		gridConstraints.insets = new Insets(10, 5, 10, 10);
		getContentPane().add(leftColorLabel, gridConstraints);

		rightColorLabel.setPreferredSize(new Dimension(40, 40));
		rightColorLabel.setOpaque(true);
		rightColorLabel.setBackground(Color.RED);
		gridConstraints = new GridBagConstraints();
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 0;
		gridConstraints.anchor = GridBagConstraints.NORTH;
		gridConstraints.insets = new Insets(10, 5, 10, 10);
		getContentPane().add(rightColorLabel, gridConstraints);

		colorPanel.setPreferredSize(new Dimension(80, 320));
		colorPanel.setBorder(BorderFactory.createTitledBorder("Colors"));
		colorPanel.setBackground(Color.LIGHT_GRAY);
		gridConstraints = new GridBagConstraints();
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 1;
		gridConstraints.gridwidth = 2;
		gridConstraints.anchor = GridBagConstraints.NORTH;
		gridConstraints.insets = new Insets(10, 10, 10, 10);
		getContentPane().add(colorPanel, gridConstraints);

		colorPanel.setLayout(new GridBagLayout());
		int j = 0;
		for (int i = 0; i < 18; i++) {
			colorLabel[i] = new JLabel();
			colorLabel[i].setPreferredSize(new Dimension(30, 30));
			colorLabel[i].setOpaque(true);
			gridConstraints = new GridBagConstraints();
			gridConstraints.gridx = j;
			gridConstraints.gridy = i - j * 9;
			colorPanel.add(colorLabel[i], gridConstraints);
			if (i == 8) {
				j++;
			}
			// listeners
			colorLabel[i].addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					colorMousePressed(e);
				}
			});

		} // temp close
			// light medium dark
		colorLabel[0].setBackground(new Color(255, 153, 153));
		colorLabel[1].setBackground(new Color(255, 26, 26));
		colorLabel[2].setBackground(new Color(128, 0, 0));
		colorLabel[3].setBackground(new Color(173, 235, 173));
		colorLabel[4].setBackground(new Color(70, 210, 70));
		colorLabel[5].setBackground(new Color(25, 103, 25));
		colorLabel[6].setBackground(new Color(153, 214, 255));
		colorLabel[7].setBackground(new Color(26, 163, 255));
		colorLabel[8].setBackground(new Color(0, 61, 102));
		colorLabel[9].setBackground(new Color(179, 255, 255));
		colorLabel[10].setBackground(new Color(0, 255, 255));
		colorLabel[11].setBackground(new Color(0, 102, 102));
		colorLabel[12].setBackground(new Color(255, 153, 255));
		colorLabel[13].setBackground(new Color(255, 0, 255));
		colorLabel[14].setBackground(new Color(102, 0, 102));
		colorLabel[15].setBackground(new Color(255, 255, 153));
		colorLabel[16].setBackground(new Color(255, 255, 26));
		colorLabel[17].setBackground(new Color(102, 102, 0));

		leftColor = colorLabel[0].getBackground();
		leftColorLabel.setBackground(leftColor);
		rightColor = colorLabel[7].getBackground();
		rightColorLabel.setBackground(rightColor);

		pack();
		setLocationRelativeTo(null);

		g2D = (Graphics2D) drawPanel.getGraphics();
	}// MouseDraw - constructor

	;

	/*
	 * private void exitForm(WindowEvent e) { //graphics close then exit
	 * g2D.dispose(); System.exit(0);
	 * 
	 * }//exitForm
	 */

	
	/*  private void exitMenuItemActionPerformed(ActionEvent e) { int response;
	  response = JOptionPane.showConfirmDialog(null,
	  "Are you sure you want to exit the program?", "Exit Program",
	  JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE); if (response ==
	  JOptionPane.NO_OPTION) { return; }else { exitForm(null); } } */
	 
	private void drawPanelMousePressed(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1 || e.getButton() == MouseEvent.BUTTON3) {
			xPrevious = e.getX();
			yPrevious = e.getY();
			if (e.getButton() == MouseEvent.BUTTON1) {
				drawColor = leftColor;
			} else {
				drawColor = rightColor;
			}
		}
		// System.out.println("mouse x, y =" + xPrevious + "," + yPrevious);

	}// end of listener

	private void drawPanelDragged(MouseEvent e) {
		Line2D.Double myLine = new Line2D.Double(xPrevious, yPrevious, e.getX(), e.getY());
		g2D.setPaint(drawColor);
		g2D.draw(myLine);
		xPrevious = e.getX();
		yPrevious = e.getY();
		System.out.println("mouse x, y = " + xPrevious + "," + yPrevious);
	}

	private void drawPanelMouseReleased(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1 || e.getButton() == MouseEvent.BUTTON3) {
			Line2D.Double myLine = new Line2D.Double(xPrevious, yPrevious, e.getX(), e.getY());
			g2D.setPaint(drawColor);
			g2D.draw(myLine);
		}
	}

	private void colorMousePressed(MouseEvent e) {
		Component clickedColor = e.getComponent();
		// make audible tone and set drawing color

		if (e.getButton() == MouseEvent.BUTTON1) {
			leftColor = clickedColor.getBackground();
			leftColorLabel.setBackground(leftColor);
		} else if (e.getButton() == MouseEvent.BUTTON3) {
			rightColor = clickedColor.getBackground();
			rightColorLabel.setBackground(rightColor);
		}

	}// End of listener

	/*
	 * private void drawPanelMouseDragged(MouseEvent e) { Line2D.Double myLine = new
	 * Line2D.Double(xPrevious, yPrevious, e.getX(), e.getX());
	 * g2D.setPaint(drawColor); g2D.draw(myLine); xPrevious = e.getX(); yPrevious =
	 * e.getY(); System.out.println("mouse x, y = " + xPrevious + "," + yPrevious);
	 * 
	 * }
	 */

	private void newMenuItemActionPerformed(ActionEvent e) {
		int response;
		response = JOptionPane.showConfirmDialog(null, "Are you sure you want to start a new drawing?", "New Drawing",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (response == JOptionPane.YES_OPTION) {
			g2D.setPaint(drawPanel.getBackground());
			g2D.fill(new Rectangle2D.Double(0, 0, drawPanel.getWidth(), drawPanel.getHeight()));
		}
	}
	
	private void blackMenuItemActionPerformed(ActionEvent e) {
		drawPanel.setBackground(Color.BLACK);
		
	}
	
	private void yellowMenuItemActionPerformed(ActionEvent e) {
		drawPanel.setBackground(Color.YELLOW);
		
	}
	
	private void redMenuItemActionPerformed(ActionEvent e) {
		drawPanel.setBackground(Color.red);
		
	}
	
	private void fineMenuItemActionPerformed(ActionEvent e) {
		g2D.setStroke(new BasicStroke(1));
		
	}
	
	private void smallMenuItemActionPerformed(ActionEvent e) {
		g2D.setStroke(new BasicStroke(5));
		
	}
	
	private void mediumMenuItemActionPerformed(ActionEvent e) {
		g2D.setStroke(new BasicStroke(9));
		
	}
	
	private void largeMenuItemActionPerformed(ActionEvent e) {
		g2D.setStroke(new BasicStroke(20));;
		
	}
	


} // Mouse draw class
