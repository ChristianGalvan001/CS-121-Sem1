package mousedraw;

public class StartHere {
	
	public static void main(String args[])
	{
		//Contstruct frame
		new MouseDraw().setVisible(true);
	}
	
}
