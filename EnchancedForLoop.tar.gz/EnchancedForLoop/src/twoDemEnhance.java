
public class twoDemEnhance {

	public static void main(String[] args) {
		
		int a=5, b=6,c=7,d=8;
		int x[] = {5,6,7,8};
		int y[] = {6,7,8,9};
		int z[] = {9,8,7,6};
		
		int p[][] = {
				{5,6,7,8},
				{6,7,8,9},
				{9,8,7,6}
		};
		
		//have to make it and array for the identifier; The second for loop doesn't because it is just one array
		//after the first for loop
		for(int i[]: p)
		{
			for(int j: i) {
			System.out.print(j + " ");
			}
			System.out.println("");
		}
		
		/* Slow
		for(int i =0; i<3; i++) 
		{
			for(int j=0;j<4;j++)
			{
				System.out.print(p[i][j] + " ");
			}
			System.out.println("");
		}
		*/
		

	}

}
