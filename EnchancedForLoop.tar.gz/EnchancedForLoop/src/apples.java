import java.util.ArrayList;
import java.util.List;

public class apples {
	public static void main(String args[])
	{
		int bucky[] = {3,4,5,6,7};
		int total = 0;
		
		
		//loop through elements in array
		//type and identifier; bucky is the array
		
		for(int x: bucky)
			{
			//adds the array # to total
			total += x;
			}
		
		System.out.println(total);
	}
	/*
	 * CoinCollectionTools tools = new CoinCollectionTools("USA", 3, 4);
		int [] years = {1,2,4,1,2,3,3,4,4,2,4};
		int [] types = {1,2,4,1,2,3,3,4,4,2,4};
		String[] typeNames = {"", "penny", "nickel", "dime", "quarter"};
		Coin[][] coinBox = new Coin[3][4];
		ArrayList<Coin> coins = new ArrayList<Coin>();
		
		
		for (int i = 0; i < years.length;i++) {
			coins.add(new Coin("USA", years[i], types[i]));
		}
		System.out.println("fillCoinBox test\n");
		coinBox = tools.fillCoinBox(coins);
		
		
		for(int row = 0; row < coinBox.length;row++) {
			
			for(int col = 0;col < coinBox[row].length;col++)
				System.out.println(typeNames[coinBox[row][col].getCoinType()] + " "
						+ coinBox[row][col].getYear());
			System.out.println();
			
		}
		
		
		System.out.println("\nfillCoinTypeList test\n");
		System.out.println("\n Test:");
		coins = tools.fillCoinTypeList();
		for (int i = 0; i < coins.size(); i++) {
			System.out.println(typeNames[coins.get(i).getCoinType()] + " " + coins.get(i).getYear()+ ", ");
			if (i == (coins.size() / 2 )) {
				System.out.println();
			}
			
		}
	 */
	
}
