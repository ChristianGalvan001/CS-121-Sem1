import java.util.ArrayList;
import java.util.List;

public class pears {

	public static void main(String[] args) {

		List<String> ListOfStrings = new ArrayList<String>();
		
		ListOfStrings.add("AAA");
		ListOfStrings.add("BBB");
		ListOfStrings.add("CCC");
		ListOfStrings.add("DDD");
		ListOfStrings.add("EEE");
		ListOfStrings.add("FFF");
		ListOfStrings.add("GGG");
		ListOfStrings.add("HHH");
		
		/* Slow way
		System.out.println("\nList items: ");
		for(int i = 0; i < ListOfStrings.size(); i++) {
			System.out.println(ListOfStrings.get(i));
		}
		System.out.println("\n" + ListOfStrings.remove(0));
		*/
		
		// Enhanced Forloop; type, identifier: array
		System.out.println("\nList items: ");
		for(String s : ListOfStrings) {
			System.out.println(s);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}//end of main

}//end of clase
